﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;
/**
 * 04/28/2020
 * CSC 153
 * Sean Mulvey
 * gives discount based on total spent
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            PreferredCustomer customer = new PreferredCustomer();
            customer.customerNumber = "00001";
            customer.Name = "Sean";
            customer.Address = "123 Sesame Street";
            customer.Phone = "(555) 555 - 5555";
            customer.mailList = true;

            customer.DisCustomer();
            Console.ReadLine();
        }
    }
}
