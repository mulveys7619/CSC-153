﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class PreferredCustomer : Customer
    {
        public string mail;
        public string strTotalSales;
        public double check;
        public double totalSales;
        public void DisCustomer()
        {
            

            if (mailList == true)
            {
                mail = "yes";

            }
            else
            {
                mail = "no";
            }
            Console.Write("Enter the total spent by customer: ");
            strTotalSales = Console.ReadLine();
            while (!double.TryParse(strTotalSales, out check))

            {
                Console.Write("Enter the total spent by customer: ");
                strTotalSales = Console.ReadLine();
            }
            totalSales = Convert.ToDouble(strTotalSales);
            if (totalSales >= 2000)
            {
                discount = 10;
            }
            else if (totalSales >= 1500)
            {
                discount = 7;
            }
            else if (totalSales >= 1000)
            {
                discount = 6;
            }
            else if (totalSales >= 500)
            {
                discount = 5;
            }
            else
            {
                discount = 0;
            }


            Console.WriteLine("Customer Number: " + customerNumber);
            Console.WriteLine("Name: " + Name);
            Console.WriteLine("Address: " + Address);
            Console.WriteLine("Phone: " + Phone);
            Console.WriteLine("Mailing List: " + mail);
            Console.WriteLine("Discount: " + discount + "%");
        }
    }
}
