﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "Choose an option from the menu\n" +
                   "==============================\n" +
                   "1. View Items\n" +
                   "2. Add Item\n" +
                   "3. Exit\n";
        }
        public static string ChoiceError()
        {
            return "ERROR: Please enter a valid option!";
        }
        public static string AddItemDescript()
        {
            return "Add Item Description: ";
        }
        public static string AddItemUnit()
        {
            return "Add Number of Units: ";
        }
        public static string AddItemPrice()
        {
            return "Add Item Price: ";
        }
        public static string DisplayItem(string descript, int units, double price)
        {
            return $"Description: {descript}\n" +
                   $"Units Available: {units}\n" +
                   $"Price: {price.ToString("C")}";
        }
       
    }
}
