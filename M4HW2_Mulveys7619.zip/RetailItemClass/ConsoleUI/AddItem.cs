﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;


namespace ConsoleUI
{
    class AddItem
    { 
    

        public static void AddAnItem(RetailItem addItem)
        {

            int intCheck = 0;
            double doubleCheck = 0.0;

            Console.WriteLine(ClassLibrary.StandardMessages.AddItemDescript());
            addItem.Description = Console.ReadLine();
            Console.WriteLine();
           
            
            Console.WriteLine(ClassLibrary.StandardMessages.AddItemUnit());
            string inputUnit = Console.ReadLine();
            
           
            while (!int.TryParse(inputUnit, out intCheck))
            {
                Console.WriteLine(ClassLibrary.StandardMessages.ChoiceError());
                inputUnit = Console.ReadLine();
            }
            
            addItem.UnitsOnHand = Convert.ToInt32(inputUnit);



            Console.WriteLine();
            Console.WriteLine(StandardMessages.AddItemPrice());
            string inputPrice = Console.ReadLine();

            while (!Double.TryParse(inputPrice, out doubleCheck))
            {
                Console.WriteLine(ClassLibrary.StandardMessages.ChoiceError());
                inputPrice = Console.ReadLine();
            }
            addItem.Price = Convert.ToDouble(inputPrice);


        }
    }
}
