﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

/**
 * 03/29/2020
 * CSC 153
 * Sean Mulvey
 * Display and add item description, inventory and price
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            RetailItem item = new RetailItem();

            
            List<string> description = new List<string>();
            description.Add("Jacket");
            description.Add("Jeans");
            description.Add("Shirt");

            List<int> units = new List<int>();
            units.Add(12);
            units.Add(40);
            units.Add(20);

            List<Double> price = new List<double>();
            price.Add(59.05);
            price.Add(34.95);
            price.Add(24.95);

            do
            {
                Console.WriteLine(ClassLibrary.StandardMessages.DisplayMenu());

                switch (Console.ReadLine())
                {
                    case "1":
                        int items = 0;
                        
                        while (items < description.Count())
                        {
                            Console.WriteLine(ClassLibrary.StandardMessages.DisplayItem(description[items], units[items], price[items]));
                            Console.WriteLine();
                            items++;
                        }
                        break;
                    case "2":
                        AddItem.AddAnItem(item);
                        description.Add(item.Description);
                        units.Add(item.UnitsOnHand);
                        price.Add(item.Price);
                        break;
                    case "3":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(ClassLibrary.StandardMessages.ChoiceError());
                        break;
                }
               
                Console.WriteLine();
                Console.WriteLine();
            } while (exit == false);
        }
    }
}
