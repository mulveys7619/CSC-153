﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        public static void Main(string[] args)
        {
            ShowDistance();
        }
        public static void ShowDistance()
        {
            Console.Write("How many seconds has the object fallen?: ");
            double secondsFallen = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("Distance the object fell: " + ClassLibrary.Formula.FallFormula(secondsFallen)+ " meters");
            Console.ReadLine();
        }
    }
}
