﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Formula
    {
        public static double FallFormula(double seconds)
        {
            double g = 9.8;
            double exponent = Math.Pow(seconds, 2);
            double distance = .5 * g * exponent;

            return distance;
        }
    }
}
