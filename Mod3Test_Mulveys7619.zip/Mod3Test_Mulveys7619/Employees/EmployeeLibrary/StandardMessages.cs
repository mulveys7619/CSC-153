﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class StandardMessages
    {
        public static String Menu()
        {
            return "1. Enter employee's name\n" +
                   "2. Enter employee's phone number\n" +
                   "3. Enter employee's age\n" +
                   "4. Display employee's information\n" +
                   "5. Display average age of employees\n" +
                   "6. Exit\n" +
                   "-->";
        }
        // Create EnterName method
        public static String EnterName()
        {
            String EnterNamePrompt = "Enter Employee's name: ";

            return EnterNamePrompt;
        }

        // Create EnterNumber method
        public static String EnterNumber()
        {
            String EnterNumberPrompt = "Enter employee's phone number: ";

            return EnterNumberPrompt;
        }

        // Create EnterAge method
        public static String EnterAge()
        {
            String EnterAgePrompt = "Enter employee's age: ";

            return EnterAgePrompt;

        }

        // Create DisplayEmployee method
        public static String DisplayEmployee(String[] name, String[] number, List<int> age)
        {


            return "Employee name: {name[index]}\n" +
                   "Employee phone: {number[index]}\n" +
                   "Employee age: {age[index]}";
        }

        // Create DisplayAverageAge method
        public static int DisplayAverageAge(List<int> num)
        {
            return Convert.ToInt32(num.Average());

        }

        public static String ExceptionHandle()
        {
            return "ERROR: Please enter an integer: ";
        }


    }
}
