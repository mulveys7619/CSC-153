﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        
        
        public static void Main(string[] args)
        {

            PlayerHealth PHp = new PlayerHealth();

            Console.WriteLine(StandardMessages.StartMenu());
            switch (Console.ReadLine())
            {
                case "1":
                    Console.WriteLine(StandardMessages.DisRoomDirection(RoomDirection.StartDirection()));
                    DecisionStructures.DungeonChoiceStructure();
                    break;
                case "2":

                    DecisionStructures.InfoMenuChoiceStructure();
                    
                    break;
                case "3":
                    Console.WriteLine(StandardMessages.Exit());
                    break;
                default:
                    StandardMessages.ChoiceError();
                    
                    break;

            }

            Console.ReadLine();
                
        }

    }
}
