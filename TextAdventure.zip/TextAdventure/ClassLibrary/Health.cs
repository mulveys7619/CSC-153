﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Health
    {
        private int _health;
        public Health()
        {
            hp = 100;
        }
        public Health(int health)
        {
            hp = health;
        }
        public int hp
        {
            get
            {
                return _health;
            }
            set
            {
                _health = value;
            }
        }
    }
}
