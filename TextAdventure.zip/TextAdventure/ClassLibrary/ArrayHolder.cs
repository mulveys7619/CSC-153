﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class ArrayHolder
    {
        public static Array RarityArray()
        {
            string[] rarityArray = { "Common", "Uncommon", "Rare", "Legendary", "Mythic" };
            return rarityArray;
        }
        public static Array ItemDescriptionArray()
        {
            string[] itemArray = { "Amulet of Resurrection (Rare,Usable: All Classes)", "Amulet of Vitality (Uncommon, Usable: All Classes)", 
                                   "Ring of Mana (Common,Usable: Templar,Rogue,Archmage)", "Ring of Stamina (Common, Usable: Dwarf)" };

            return itemArray;
        }
        public static Array MobArray()
        {
            string[] mobArray = { "Goblin Lackey", "Goblin Captain", "Goblin Mage", "Hobgoblin", "Goblin Commander", "Goblin King" };
            return mobArray;
        }
        public static Array StatArray()
        {
            string[] statArray = { "Health", "Mana", "Dexterity", "Speed", "Defense", "Attack", "Vitality", "Wisdom" };
            return statArray;
        }
        public static Array AbilityArray()
        {
            string[] abilityArray = { "Charge (Usable: Dwarf)", "God's Might(usable: Templar)", "Backstab (Usable: Rogue)", "Firebolt(Usable: Archmage)" };
            return abilityArray;
        }
        public static Array WeaponArray()
        {
            string[] weaponArray = { "Rusty Battleaxe (Common,One-handed,Usable: Dwarf, Templar)", "Rusty Claymore (Common,Two-handed,Usable: Dwarf, Templar)", 
                "Worn Shield (Common,Usable:(Only usable with One-handed weapons) Dwarf, Templar)","Rusty Assassin Dagger (Common,One-handed,Usable: Rogue)", 
                "Splintered Staff (Common,Two-handed,Usable: Archmage)" };
            return weaponArray;
        }
        public static Array ClassArray()
        {
            string[] classArray = { "Dwarf", "Templar", "Archmage", "Rogue" };
            return classArray;
        }
        public static Array RoomDirecArray()
        {
            string[] roomDirectionArray = { "NSEW", "W", "S", "SW", "EW", "E", "SE", "N", "NS", "NW", "NE" };

            return roomDirectionArray;
        }
        public static Array RoomTypeArray()
        {
            string[] roomTypeArray = { "Entrance", "Hall", "Mob", "Treasure", "Boss" };
            return roomTypeArray;
        }
        public static Array PotionArray()
        {
            string[] potionArray = { "Potion of Health", "Potion of Mana" };
            return potionArray;
        }
        public static Array TreasureArray()
        {
            string[] treasureArray = { "Gold", "Silver", "Ruby", "Emerald", "Saphire", "Diamond", "Item" };
            return treasureArray;
        }
    }
}
