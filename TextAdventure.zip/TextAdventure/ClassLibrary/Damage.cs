﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Damage
    {
        public int DamageTaken()
        {
            Random rand = new Random();

            int damage = rand.Next(1, 20);
            return damage;
        }
        public int DamageDealt()
        {
            Random rand = new Random();

            int damage = rand.Next(1, 20);

            return damage;
        }

    }
}
