﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class PlayerHealth : Health
    {
        
        public int PlayerHp()
        {
            
            return hp;
        }

        public int PlayerTakeDamage(int health, int damage)
        {
            hp = health - damage;
            
            return hp;
        }
    }
}
