﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {

        public static string StartMenu()
        {
            return "Please select an option from the menu below\n" +
                  "===========================================\n" +
                  "1. Enter Dungeon\n" +
                  "2. Game Information\n" +
                  "3. Exit\n" +
                  "";
        }
        public static string InfoMenu()
        {
            return "This menu provides information on various aspects of the Dungeon Crawler game\n" +
            "------------------------------------------------------------------------------\n" +
            "Select an option from the menu below to learn more about it.\n" +
            "==============================================================================\n" +
            "1. Beginner Classes\n" +
            "2. Dungeon Rooms\n" +
            "3. Potions\n" +
            "4. Treasure\n" +
            "5. Items\n" +
            "6. Weapons\n" +
            "7. Abilities\n" +
            "8. Mobs\n" +
            "9. Stats\n" +
            "10. Exit\n" +
            "Please select an option (1-10): ";
        }
        public static string ChoiceError()
        {
            return "ERROR: Please select a valid option!";
        }
        public static String CritHitTaken(int damage)
        {
            return "You were critically hit for " + damage + " points!";
        }
        public static String NormHitTaken(int damage)
        {
            return "You were dealt " + damage + " points of damage";
        }
        public static String CritHitDealt(int damage)
        {
            return "You critically hit for " + damage + " points!";
        }
        public static String NormHitDealt(int damage)
        {
            return "You  dealt " + damage + " points of damage";
        }
        public static string ItemDescriptionHeader()
        {
            return "Items\n" +
                   "-----\n";
        }
        public static string RarityHeader()
        {
            return "RARITY (Ascending Order)\n" +
            "-----------------------------\n";
        }
        public static string MobHeader()
        {
            return "MOBS\n" +
                   "----\n";
        }
        public static string StatHeader()
        {
            return "STATS\n" +
                   "-----\n";
        }
        public static string AbilityHeader()
        {
            return "ABILITIES\n" +
                   "---------\n";
        }
        public static string WeaponHeader()
        {
            return "WEAPONS\n" +
                   "-------\n";
        }
        public static string ClassHeader()
        {
            return "CLASSES\n" +
            "------------";
        }
        public static string RoomDirecHeader()
        {
            return "Room Directions\n" +
                   "---------------\n";
        }
        public static string RoomTypeHeader()
        {
            return "Room Types\n" +
                   "----------\n";
        }
        public static string PotionHeader()
        {
            return "Potions\n" +
                   "-------\n";
        }
        public static string TreasureHeader()
        {
            return "Treasure Types\n" +
                   "--------------\n";
        }
        public static string Exit()
        {
            return "Thank you for playing!";
        }
        public static string DisRoomDirection(string enterDirection)
        {
            return "You enter the dungeon form the " + enterDirection + ".";
        }
        public static string DisDungeonOptionMenu(string directionFrom)
        {
            string optionMenu = "";
            switch (directionFrom)
            {
                case "North":
                    optionMenu = "Choose a direction to go\n" +
                   "1. South\n" +
                   "2. East\n" +
                   "3. West\n" +
                   "4. Attack\n" +
                   "5. Exit Dungeon";
                    break;
                case "South":
                    optionMenu = "Choose a direction to go\n" +
                   "1. North\n" +
                   "2. East\n" +
                   "3. West\n" +
                   "4. Attack\n" +
                   "5. Exit Dungeon";
                    break;
                case "East":
                    optionMenu = "Choose a direction to go\n" +
                   "1. West\n" +
                   "2. North\n" +
                   "3. South\n" +
                   "4. Attack\n" +
                   "5. Exit Dungeon";
                    break;
                case "West":
                    optionMenu = "Choose a direction to go\n" +
                   "1. East\n" +
                   "2. South\n" +
                   "3. North\n" +
                   "4. Attack\n" +
                   "5. Exit Dungeon";
                    break;
                default:
                    Console.WriteLine(StandardMessages.FatalError());
                    break;
            }
            return optionMenu;
        }

        public static string DisPlayerHP(int damage, int hp)
        {
            if (damage > 10)
            {
                return "You were critically hit for " + damage + " points of damage!\n" +
                    "Your HP: " + hp;
            }
            else
            {
                return "You were hit for " + damage + " points of damage\n" +
                    "Your HP: " + hp;
            }
            
        }
        public static string DisMobHP(int damage, int hp)
        {
            if (damage > 10)
            {
                return "You critically hit for " + damage + " points of damage!\n" +
                    "Mob HP: " + hp;
            }
            else
            {
                return "You hit for " + damage + " points of damage\n" +
                    "Mob HP: " + hp;
            }

        }

        public static string FatalError()
        {
            return "An unknown error has occured. Please restart the program.";
        }
        public static string LeaveDungeon()
        {
            return "You are in the start room.\n" +
                "Are you sure you would like to exit the dungeon?(y/n):";
        }
      
        
    }
}
