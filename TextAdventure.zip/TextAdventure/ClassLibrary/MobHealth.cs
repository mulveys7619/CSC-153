﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class MobHealth : Health
    {

        public int MobHp()
        {

            return hp;
        }

        public int MobTakeDamage(int health, int damage)
        {
            hp = health - damage;

            return hp;
        }
    }
}
