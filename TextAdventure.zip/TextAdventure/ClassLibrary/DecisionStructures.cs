﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClassLibrary
{
    public class DecisionStructures
    {
        public static void InfoMenuChoiceStructure()
        {
            bool exit = false;
            do
            {
                Console.Write(StandardMessages.InfoMenu());
                

                switch (Console.ReadLine())
                {
                    case "1":
                        BuildArray.DisClassArray();
                        Console.ReadLine();
                        break;
                    case "2":
                        BuildArray.DisRoomArray();
                        break;
                    case "3":
                        BuildArray.DisPotionArray();
                        break;
                    case "4":
                        BuildArray.DisTreasureArray();
                        break;
                    case "5":
                        BuildArray.DisItemArray();
                        Console.ReadLine();
                        break;
                    case "6":
                        BuildArray.DisWeaponArray();
                        Console.ReadLine();
                        break;
                    case "7":
                        BuildArray.DisAbilityArray();
                        Console.ReadLine();
                        break;
                    case "8":
                        BuildArray.DisMobArray();
                        Console.ReadLine();
                        break;
                    case "9":
                        BuildArray.DisStatArray();
                        Console.ReadLine();
                        break;
                    case "10":
                        StandardMessages.Exit();
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.ChoiceError());

                        break;

                }
            } while (exit == false);
        }
        public static void DungeonChoiceStructure()
        {
            string menuChoice;
            PlayerHealth playerHP = new PlayerHealth();
            Damage damage = new Damage();
            MobHealth mobHP = new MobHealth();
            Random rand = new Random();
            
            

            Console.WriteLine(StandardMessages.DisDungeonOptionMenu(RoomDirection.StartDirection()));

            menuChoice = Console.ReadLine();

            while (menuChoice != "5")
            {
                Console.WriteLine(StandardMessages.DisDungeonOptionMenu(RoomDirection.StartDirection()));

                menuChoice = Console.ReadLine();
                switch (menuChoice)
                {
                    case "1":
                        if (RoomTracker.track <= 0)
                        {
                            Console.WriteLine(StandardMessages.LeaveDungeon());
                            string leave;
                            leave = Console.ReadLine();
                            if (leave == "y")
                            {
                                Console.WriteLine(StandardMessages.StartMenu());
                                switch (Console.ReadLine())
                                {
                                    case "1":
                                        DecisionStructures.DungeonChoiceStructure();
                                        break;
                                    case "2":

                                        DecisionStructures.InfoMenuChoiceStructure();

                                        break;
                                    case "3":
                                        Console.WriteLine(StandardMessages.Exit());
                                        break;
                                    default:
                                        StandardMessages.ChoiceError();

                                        break;

                                }
                            }
                            else
                            {
                                DungeonChoiceStructure();
                                RoomTracker.track = RoomTracker.track - 1;
                            }

                        }
                        break;
                    case "2":
                        RoomTracker.track = RoomTracker.track + 1;
                        DungeonChoiceStructure();
                        break;
                    case "3":
                        RoomTracker.track = RoomTracker.track + 1;
                        DungeonChoiceStructure();
                        break;


                    case "4":
                        Console.WriteLine(damage.DamageTaken());
                        Console.WriteLine(damage.DamageDealt());
                        Console.WriteLine(StandardMessages.DisPlayerHP(damage.DamageTaken(), playerHP.PlayerTakeDamage(playerHP.PlayerHp(), damage.DamageTaken())));
                        Console.WriteLine(StandardMessages.DisMobHP(damage.DamageTaken(), mobHP.MobTakeDamage(mobHP.MobHp(), damage.DamageDealt())));
                        break;
                    case "5":
                        Console.WriteLine(StandardMessages.StartMenu());
                        break;

                }
            }
        }
    }
}
