﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class RoomDirection
    {
       
        public static string StartDirection()
        {
            Random random = new Random();
            string direction = "";
            switch (random.Next(1,4))
            {
                case 1:
                    direction = "North";
                    break;
                case 2:
                    direction = "South";
                    break;
                case 3:
                    direction = "East";
                    break;
                case 4:
                    direction = "West";
                    break;
                default:
                    Console.WriteLine(StandardMessages.FatalError());
                    Console.ReadLine();
                    break;

            }


            return direction;
        }
        

        



    }
}
