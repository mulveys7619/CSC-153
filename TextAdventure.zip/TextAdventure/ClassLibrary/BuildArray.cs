﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class BuildArray
    {
        private string[] _items;


        public BuildArray()
        {
            Items = new string[] {""};
        }

        public BuildArray(string[] items)
        {
            Items = items;
        }

        public string[] Items
        {
            get
            {
                return _items;
            }
            set
            {
                _items = value;
            }
        }
        public static string BuildAnArray(Array items)
        {
            
            foreach (string item in items)
            {
                Console.WriteLine(item);
            }
            // Changed from void to string because compiler threw error: "could not convert 'void' to 'bool'
            return "";
        }
        public static void DisItemArray()
        {
            
            Console.WriteLine(StandardMessages.ItemDescriptionHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.ItemDescriptionArray()));
            Console.WriteLine();
            Console.WriteLine(StandardMessages.RarityHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.RarityArray()));
            Console.WriteLine();
        }
        public static void DisMobArray()
        {
            Console.WriteLine(StandardMessages.MobHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.MobArray()));
            Console.WriteLine();
           
          
        }

        public static void DisStatArray()
        {
            Console.WriteLine(StandardMessages.StatHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.StatArray()));
            Console.WriteLine();
        }
        public static void DisAbilityArray()
        {
            Console.WriteLine(StandardMessages.AbilityHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.AbilityArray()));
            Console.WriteLine();
        }
        public static void DisWeaponArray()
        {
            Console.WriteLine(StandardMessages.WeaponHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.WeaponArray()));
            Console.WriteLine();
            Console.WriteLine(StandardMessages.RarityHeader());
            Console.WriteLine();

        }
        public static void DisClassArray()
        {
            Console.WriteLine(StandardMessages.ClassHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.ClassArray()));
            Console.WriteLine();
            
        }
        public static void DisRoomArray()
        {
            Console.WriteLine(StandardMessages.RoomDirecHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.RoomDirecArray()));
            Console.WriteLine();
            Console.WriteLine(StandardMessages.RoomTypeHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.RoomTypeArray()));
        }
        public static void DisPotionArray()
        {
            Console.WriteLine(StandardMessages.PotionHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.PotionArray()));
            Console.WriteLine();
        }
        public static void DisTreasureArray()
        {
            Console.WriteLine(StandardMessages.TreasureHeader());
            Console.WriteLine(BuildAnArray(ArrayHolder.TreasureArray()));
            Console.WriteLine();
        }
        
    }
}
