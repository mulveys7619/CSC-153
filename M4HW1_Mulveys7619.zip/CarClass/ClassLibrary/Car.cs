﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Car
    {
        // Create Fields
        private string _year;
        private string _make;
        

        // Create Constructor
        public Car()
        {
            Year = "";
            Make = "";
            Speed = 0;
        }

        public Car (string year,string make, int speed)
        {
            Year = year;
            Make = make;
            Speed = speed;

        }

        // Create Full Property
        public string Year
        {
            get
            {
                return _year;
            }
            set
            {
                _year = value;

            }
        }
        public string Make
        {
            get
            {
                return _make;
            }
            set
            {
                _make = value;
            }
        }
        public int Speed
        {
            get;
            set;

        } = 0;
    }
}
