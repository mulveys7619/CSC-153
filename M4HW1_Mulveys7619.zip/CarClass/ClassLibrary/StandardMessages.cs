﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string StartMenu()
        {
            return "Choose an option from the menu\n" +
                   "==============================\n" +
                   "1. Create Car\n" +
                   "2. Accelerate\n" +
                   "3. Brake\n" +
                   "4. Exit";
        }
        public static string MenuError()
        {
            return "ERROR: Please select a valid option!";
        }
        public static string InputCarYear()
        {
            return "What year is the car?: ";
        }
        public static string InputCarMake()
        {
            return "What nake is the car?: ";
        }
        public static string DisplayCarInfo(string year, string make)
        {
            return "Car Year:" + year + "\n" +
                   "Car Make:" + make;
        }

        public static string DisplaySpeedInfo(int speed)
        {
            return "Speed: " + speed + "MPH";
        }
        public static string InputError()
        {
            return "ERROR: Please create a car!";
        }
    }
   
}
