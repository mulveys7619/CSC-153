﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Customer : Person
    {
        public string customerNumber;
        public bool mailList;

        public void DisCustomer()
        {
            string check;
            if (mailList == true)
            {
                check = "yes";

            }
            else
            {
                check = "no";
            }
            Console.WriteLine("Customer Number: " + customerNumber);
            Console.WriteLine("Name: " + Name);
            Console.WriteLine("Address: " + Address);
            Console.WriteLine("Phone: " + Phone);
            Console.WriteLine("Mailing List: " + check);
        }
    }
}
