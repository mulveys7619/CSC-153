﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string DisplayStartMenu()
        {
            return "1. Enter employee's information\n"+
            "2. Display employee information\n"+
            "3. Display average age of employees\n"+
            "4. Exit\n"+
            "-->";
            
        }
        public static string ChoiceError()
        {
            return "ERROR: Please choose a valid option";
        }
        public static string GetName()
        {
            return "Enter employee's name: ";
        }
        public static string GetPhone()
        {
            return "Enter employee's phone number: ";
        }
        public static string GetAge()
        {
            return "Enter employee's age: ";
        }
        public static string DisplayInfo(string name, string phone, int age)
        {
            return $"Employee name: {name}\n" +
                $"Employee phone number: {phone}\n" +
                $"Employee age: {age}";
        }
        public static string DisplayAverage(List<int> average)
        {
            return $"Average employee age: {average.Average()} ";
        }
    }
}
