﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Employee
    {
        private string _name;
        private string _phone;
        private int _age;
        public Employee()
        {
            Name = "";
            Phone = "";
            Age = 0;
        }
        public Employee(string name,string phone,int age)
        {
            Name = name;
            Phone = phone;
            Age = age;
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string Phone
        {
            get
            {
                return _phone;
            }
            set
            {
                _phone = value;
            }
        }
        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }

        public static void BuildEmployee(Employee inputInfo)
        {
           
            Console.Write(StandardMessages.GetName());
            inputInfo.Name = Console.ReadLine();
            Console.WriteLine();
            Console.Write(StandardMessages.GetPhone());
            inputInfo.Phone = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine(StandardMessages.GetAge());
            inputInfo.Age = Convert.ToInt32(Console.ReadLine());

        }
    }
}
