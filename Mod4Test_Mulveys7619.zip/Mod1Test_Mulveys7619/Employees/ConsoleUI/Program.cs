﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create input var for user input and sentry for loop
            string input;
            bool exit = false;

            Employee info = new Employee();

            int counter = 0;
            // Create Const var
            const int SIZE = 5;

            
            

            // Create arrays for names and numbers
            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];

            // Create list for age
            List<int> employeeAge = new List<int>();

            int len = 0;
           

            do
            {
                Console.Write(ClassLibrary.StandardMessages.DisplayStartMenu());
                input = Console.ReadLine();

                // Switch to direct to proper process
                switch (input)
                {
                    case "1":

                        Employee.BuildEmployee(info);
                        employeeNames[counter] = info.Name;
                        employeePhone[counter] = info.Phone;
                        employeeAge.Add(info.Age);
                        counter++;
                        break;
                    case "2":
                        while(len < employeeNames.Length)
                        {
                            foreach (string i in employeeNames)
                            {
                                Console.WriteLine(ClassLibrary.StandardMessages.DisplayInfo(employeeNames[len], employeePhone[len], employeeAge[len]));
                                len++;

                            }
                        }
                        
                        
                        break;
                    case "3":
                        Console.WriteLine(ClassLibrary.StandardMessages.DisplayAverage(employeeAge));
                        break;
                    case "4":
                        exit = true;
                        
                        break;
                    default:
                        Console.WriteLine(ClassLibrary.StandardMessages.ChoiceError());
                        break;
                }

            }
            while (exit == false);

        }
    }
}
