﻿/*
 * 02/07/2020
 * CSC 153
 * Sean Mulvey
 * Displays information menu about Dungeon Crawler
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            void InfoMenu()
            {
                // Set variable for user's menu option choice
                int menuChoice;
                // Create a menu that allows the user to see information about varied aspects of the dungeon crawler
                Console.WriteLine("This menu provides information on various aspects of the Dungeon Crawler game");
                Console.WriteLine("------------------------------------------------------------------------------");
                Console.WriteLine("Select an option from the menu below to learn more about it.");
                Console.WriteLine("==============================================================================");
                Console.WriteLine("1. Beginner Classes");
                Console.WriteLine("2. Dungeon Rooms");
                Console.WriteLine("3. Potions");
                Console.WriteLine("4. Treasure");
                Console.WriteLine("5. Items");
                Console.WriteLine("6. Weapons");
                Console.WriteLine("7. Abilities");
                Console.WriteLine("8. Mobs");
                Console.WriteLine("9. Stats");
                Console.WriteLine("10. Exit");
                Console.WriteLine();
                Console.Write("Please select an option (1-10): ");
                menuChoice = Convert.ToInt32(Console.ReadLine());

                // Create if else if statement in order to call user's choice
                if (menuChoice == 1)
                {
                    ClassInfo();
                }

                else if (menuChoice == 2)
                {
                    RoomInfo();
                }
                else if (menuChoice == 3)
                {
                    PotionInfo();
                }
                else if (menuChoice == 4)
                {
                    TreasureInfo();
                }
                else if (menuChoice == 5)
                {
                    ItemInfo();
                }
                else if (menuChoice == 6)
                {
                    WeaponInfo();
                }
                else if (menuChoice == 7)
                {
                    AbilityInfo();
                }
                else if (menuChoice == 8)
                {
                    MobInfo();
                }
                else if (menuChoice == 9)
                {
                    StatInfo();
                }
                else if (menuChoice == 10)
                {
                    Exit();
                }
                // Create else statement in case user chooses an inavlid option
                else
                {
                    Console.WriteLine("ERROR: Please select a valid option (1-10) from the Menu.");
                    Console.WriteLine();
                    Console.WriteLine();
                    InfoMenu();

                }


            }
            // Create a method to display class info
            void ClassInfo()
            {

                // Create array containing the four starter classes
                string[] classArray = { "Dwarf", "Templar", "Archmage", "Rogue" };

                Console.WriteLine("CLASSES");
                Console.WriteLine("------------");
                foreach (string type in classArray)
                {
                    Console.WriteLine(type);
                }

                // Create way for user to select another option form the menu or exit
                void ContClass()
                {
                    string contOption;
                    Console.Write("Would you like to view another item from the menu?(Y/N): ");
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine("ERROR: Please a valid option ('Y' or 'N').");
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();




            }
            // Create a method to display dungeon room info
            void RoomInfo()
            {
                string[] roomDirectionArray = { "NSEW", "W", "S", "SW", "EW", "E", "SE", "N", "NS", "NW", "NE" };
                string[] roomTypeArray = { "Entrance", "Hall", "Mob", "Treasure", "Boss" };

                Console.WriteLine("ROOM DIRECTIONS");
                Console.WriteLine("---------------");
                foreach (string direc in roomDirectionArray)
                {
                    Console.WriteLine(direc);
                }
                Console.WriteLine();
                Console.WriteLine("ROOM TYPES");
                Console.WriteLine("----------");
                foreach (string type in roomTypeArray)
                {
                    Console.WriteLine(type);
                }

                Console.WriteLine();

                // Create way for user to select another option form the menu or exit
                void ContClass()
                {
                    string contOption;
                    Console.Write("Would you like to view another item from the menu?(Y/N): ");
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine("ERROR: Please a valid option ('Y' or 'N').");
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();
            }
            // Create a method to display potion info
            void PotionInfo()
            {
                string[] potionArray = { "Potion of Health", "Potion of Mana" };

                Console.WriteLine("POTIONS");
                Console.WriteLine("-------");
                foreach ( string pot in potionArray)
                {
                    Console.WriteLine(pot);
                }

                Console.WriteLine();
                
                void ContClass()
                {
                    string contOption;
                    Console.Write("Would you like to view another item from the menu?(Y/N): ");
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine("ERROR: Please a valid option ('Y' or 'N').");
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();

            }
            // Create a method to display treasure info
            void TreasureInfo()
            {
                string[] treasureArray = { "Gold", "Silver", "Ruby", "Emerald", "Saphire", "Diamond","Item" };

                Console.WriteLine("TREASURE TYPES");
                Console.WriteLine("--------------");
                foreach (string treasure in treasureArray)
                {
                    Console.WriteLine(treasure);
                }
                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write("Would you like to view another item from the menu?(Y/N): ");
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine("ERROR: Please a valid option ('Y' or 'N').");
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();




            }
            // Create a method to display item info
            void ItemInfo()
            {
                string[] rarityArray = { "Common", "Uncommon", "Rare", "Legendary", "Mythic" };
                string[] itemArray = { "Amulet of Resurrection (Rare,Usable: All Classes)", "Amulet of Vitality (Uncommon, Usable: All Classes)", "Ring of Mana (Common,Usable: Templar,Rogue,Archmage)", "Ring of Stamina (Common, Usable: Dwarf)" };

                Console.WriteLine("ITEM RARITY (Ascending Order)");
                Console.WriteLine("-----------------------------");
                foreach (string rarity in rarityArray)
                {
                    Console.WriteLine(rarity);
                }
                Console.WriteLine();
                Console.WriteLine("ITEMS");
                Console.WriteLine("-----");
                foreach (string item in itemArray)
                {
                    Console.WriteLine(item);
                }
                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write("Would you like to view another item from the menu?(Y/N): ");
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine("ERROR: Please a valid option ('Y' or 'N').");
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();

            }
            // Create a method to display weapon info
            void WeaponInfo()
            {
                string[] rarityArray = { "Common", "Uncommon", "Rare", "Legendary", "Mythic" };
                string[] weaponArray = { "Rusty Battleaxe (Common,One-handed,Usable: Dwarf, Templar)", "Rusty Claymore (Common,Two-handed,Usable: Dwarf, Templar)", "Worn Shield (Common,Usable:(Only usable with One-handed weapons) Dwarf, Templar)", "Rusty Assassin Dagger (Common,One-handed,Usable: Rogue)", "Splintered Staff (Common,Two-handed,Usable: Archmage)" };
                Array.Sort(weaponArray);
                Console.WriteLine("WEAPON RARITY (Ascending Order)");
                Console.WriteLine("-------------------------------");
                foreach (string rarity in rarityArray)
                {
                    Console.WriteLine(rarity);
                }
                Console.WriteLine();
                Console.WriteLine("WEAPONS");
                Console.WriteLine("-------");
                foreach ( string weapon in weaponArray)
                {
                    Console.WriteLine(weapon);
                }
                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write("Would you like to view another item from the menu?(Y/N): ");
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine("ERROR: Please a valid option ('Y' or 'N').");
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();
            }
            // Create a method to display ability info
            void AbilityInfo()
            {
                string[] abilityArray = { "Charge (Usable: Dwarf)", "God's Might(usable: Templar)", "Backstab (Usable: Rogue)", "Firebolt(Usable: Archmage)" };
                Console.WriteLine("ABILITIES");
                Console.WriteLine("---------");
                foreach (string ability in abilityArray)
                {
                    Console.WriteLine(ability);
                }

                Console.WriteLine();
                
                void ContClass()
                {
                    string contOption;
                    Console.Write("Would you like to view another item from the menu?(Y/N): ");
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine("ERROR: Please a valid option ('Y' or 'N').");
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();

            }
            // Create a method to display mob info
            void MobInfo()
            {
                string[] mobArray = { "Goblin Lackey", "Goblin Captain", "Goblin Mage", "Hobgoblin", "Goblin Commander", "Goblin King" };
                Console.WriteLine("MOBS");
                Console.WriteLine("----");
                foreach (string mob in mobArray)
                {
                    Console.WriteLine(mob);
                }

                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write("Would you like to view another item from the menu?(Y/N): ");
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine("ERROR: Please a valid option ('Y' or 'N').");
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();

            }
            // Create a method to display stat info
            void StatInfo()
            {
                string[] statArray = { "Health", "Mana", "Dexterity", "Speed", "Defense", "Attack", "Vitality", "Wisdom" };

                Console.WriteLine("STATS");
                Console.WriteLine("-----");
                foreach ( string stat in statArray)
                {
                    Console.WriteLine(stat);
                }

                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write("Would you like to view another item from the menu?(Y/N): ");
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine("ERROR: Please a valid option ('Y' or 'N').");
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();


            }
            // Create a method to thank user for using the menu and exit
            void Exit()
            {
                Console.WriteLine("Thank you for using the Dungeon Crawler Info Menu!");
                Console.ReadLine();
            }

            InfoMenu();
            
        }
    }
}
