﻿/*
 * 02/07/2020
 * CSC 153
 * Sean Mulvey
 * Displays information menu about Dungeon Crawler
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Program
    {
       
        public static void Main(string[] args)
        {
            void StartMenu()
            {
                Console.WriteLine(ClassLibrary.DisplayMessages.DisStartMenu());
                int check = 0;
                String strChoice = Console.ReadLine();

                while (!int.TryParse(strChoice, out check))
                {
                    Console.WriteLine(ClassLibrary.DisplayMessages.MenuError());
                    Console.WriteLine();
                    Console.WriteLine();
                    StartMenu();
                }
                int choice = Convert.ToInt32(strChoice);

                switch (choice)
                {
                    case 1:
                        DungeonStart();
                        break;
                    case 2:
                        InfoMenu();
                        break;
                    case 3:
                        Exit();
                        break;
                    default:
                        Console.WriteLine(ClassLibrary.DisplayMessages.MenuError());
                        Console.WriteLine();
                        Console.WriteLine();
                        StartMenu();
                        break;

                }
            }
            void InfoMenu()
            {
                // Set variable for user's menu option choice
                String strMenuChoice;
                int check = 0;
                // Create a menu that allows the user to see information about varied aspects of the dungeon crawler
                Console.WriteLine(ClassLibrary.DisplayMessages.DisInfoMenu());
                strMenuChoice = Console.ReadLine();

                while (!int.TryParse(strMenuChoice, out check))
                {
                    Console.WriteLine(ClassLibrary.DisplayMessages.MenuError());
                    Console.WriteLine();
                    Console.WriteLine();
                    InfoMenu();

                }
                int menuChoice = Convert.ToInt32(strMenuChoice);
                Console.WriteLine();
                Console.WriteLine();

                // Create if else if statement in order to call user's choice
                switch (menuChoice)
                {
                    case 1:
                        ClassInfo();
                        break;
                    case 2:
                        RoomInfo();
                        break;
                    case 3:
                        PotionInfo();
                        break;
                    case 4:
                        TreasureInfo();
                        break;
                    case 5:
                        ItemInfo();
                        break;
                    case 6:
                        WeaponInfo();
                        break;
                    case 7:
                        AbilityInfo();
                        break;
                    case 8:
                        MobInfo();
                        break;
                    case 9:
                        StatInfo();
                        break;
                    case 10:
                        Exit();
                        break;
                    default:
                        Console.WriteLine(ClassLibrary.DisplayMessages.MenuError());
                        Console.WriteLine();
                        Console.WriteLine();
                        InfoMenu();
                        break;
                }


            }
            // Create a method to display class info
            void ClassInfo()
            {
               
                // Create array containing the four starter classes
                string[] classArray = { "Dwarf", "Templar", "Archmage", "Rogue" };

                Console.WriteLine(ClassLibrary.DisplayMessages.DisClassInfo());
                foreach (string type in classArray)
                {
                    Console.WriteLine(type);
                }

                // Create way for user to select another option form the menu or exit
                void ContClass()
                {
                    string contOption;
                    Console.Write(ClassLibrary.DisplayMessages.ChooseNew());
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine(ClassLibrary.DisplayMessages.ExceptionHandle());
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();




            }
            // Create a method to display dungeon room info
            void RoomInfo()
            {
                string[] roomDirectionArray = { "NSEW", "W", "S", "SW", "EW", "E", "SE", "N", "NS", "NW", "NE" };
                string[] roomTypeArray = { "Entrance", "Hall", "Mob", "Treasure", "Boss" };

                Console.WriteLine("ROOM DIRECTIONS");
                Console.WriteLine("---------------");
                foreach (string direc in roomDirectionArray)
                {
                    Console.WriteLine(direc);
                }
                Console.WriteLine();
                Console.WriteLine("ROOM TYPES");
                Console.WriteLine("----------");
                foreach (string type in roomTypeArray)
                {
                    Console.WriteLine(type);
                }

                Console.WriteLine();

                // Create way for user to select another option form the menu or exit
                void ContClass()
                {
                    string contOption;
                    Console.Write(ClassLibrary.DisplayMessages.ChooseNew());
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine(ClassLibrary.DisplayMessages.ExceptionHandle());
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();
            }
            // Create a method to display potion info
            void PotionInfo()
            {
                string[] potionArray = { "Potion of Health", "Potion of Mana" };

                Console.WriteLine("POTIONS");
                Console.WriteLine("-------");
                foreach ( string pot in potionArray)
                {
                    Console.WriteLine(pot);
                }

                Console.WriteLine();
                
                void ContClass()
                {
                    string contOption;
                    Console.Write(ClassLibrary.DisplayMessages.ChooseNew());
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine(ClassLibrary.DisplayMessages.ExceptionHandle());
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();

            }
            // Create a method to display treasure info
            void TreasureInfo()
            {
                string[] treasureArray = { "Gold", "Silver", "Ruby", "Emerald", "Saphire", "Diamond","Item" };

                Console.WriteLine("TREASURE TYPES");
                Console.WriteLine("--------------");
                foreach (string treasure in treasureArray)
                {
                    Console.WriteLine(treasure);
                }
                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write(ClassLibrary.DisplayMessages.ChooseNew());
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine(ClassLibrary.DisplayMessages.ExceptionHandle());
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();




            }
            // Create a method to display item info
            void ItemInfo()
            {
                string[] rarityArray = { "Common", "Uncommon", "Rare", "Legendary", "Mythic" };
                string[] itemArray = { "Amulet of Resurrection (Rare,Usable: All Classes)", "Amulet of Vitality (Uncommon, Usable: All Classes)", "Ring of Mana (Common,Usable: Templar,Rogue,Archmage)", "Ring of Stamina (Common, Usable: Dwarf)" };

                Console.WriteLine("ITEM RARITY (Ascending Order)");
                Console.WriteLine("-----------------------------");
                foreach (string rarity in rarityArray)
                {
                    Console.WriteLine(rarity);
                }
                Console.WriteLine();
                Console.WriteLine("ITEMS");
                Console.WriteLine("-----");
                foreach (string item in itemArray)
                {
                    Console.WriteLine(item);
                }
                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write(ClassLibrary.DisplayMessages.ChooseNew());
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine(ClassLibrary.DisplayMessages.ExceptionHandle());
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();

            }
            // Create a method to display weapon info
            void WeaponInfo()
            {
                string[] rarityArray = { "Common", "Uncommon", "Rare", "Legendary", "Mythic" };
                string[] weaponArray = { "Rusty Battleaxe (Common,One-handed,Usable: Dwarf, Templar)", "Rusty Claymore (Common,Two-handed,Usable: Dwarf, Templar)", "Worn Shield (Common,Usable:(Only usable with One-handed weapons) Dwarf, Templar)", "Rusty Assassin Dagger (Common,One-handed,Usable: Rogue)", "Splintered Staff (Common,Two-handed,Usable: Archmage)" };
                Array.Sort(weaponArray);
                Console.WriteLine("WEAPON RARITY (Ascending Order)");
                Console.WriteLine("-------------------------------");
                foreach (string rarity in rarityArray)
                {
                    Console.WriteLine(rarity);
                }
                Console.WriteLine();
                Console.WriteLine("WEAPONS");
                Console.WriteLine("-------");
                foreach ( string weapon in weaponArray)
                {
                    Console.WriteLine(weapon);
                }
                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write(ClassLibrary.DisplayMessages.ChooseNew());
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine(ClassLibrary.DisplayMessages.ExceptionHandle());
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();
            }
            // Create a method to display ability info
            void AbilityInfo()
            {
                string[] abilityArray = { "Charge (Usable: Dwarf)", "God's Might(usable: Templar)", "Backstab (Usable: Rogue)", "Firebolt(Usable: Archmage)" };
                Console.WriteLine("ABILITIES");
                Console.WriteLine("---------");
                foreach (string ability in abilityArray)
                {
                    Console.WriteLine(ability);
                }

                Console.WriteLine();
                
                void ContClass()
                {
                    string contOption;
                    Console.Write(ClassLibrary.DisplayMessages.ChooseNew());
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine(ClassLibrary.DisplayMessages.ExceptionHandle());
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();

            }
            // Create a method to display mob info
            void MobInfo()
            {
                string[] mobArray = { "Goblin Lackey", "Goblin Captain", "Goblin Mage", "Hobgoblin", "Goblin Commander", "Goblin King" };
                Console.WriteLine("MOBS");
                Console.WriteLine("----");
                foreach (string mob in mobArray)
                {
                    Console.WriteLine(mob);
                }

                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write(ClassLibrary.DisplayMessages.ChooseNew());
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine(ClassLibrary.DisplayMessages.ExceptionHandle());
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();

            }
            // Create a method to display stat info
            void StatInfo()
            {
                string[] statArray = { "Health", "Mana", "Dexterity", "Speed", "Defense", "Attack", "Vitality", "Wisdom" };

                Console.WriteLine("STATS");
                Console.WriteLine("-----");
                foreach ( string stat in statArray)
                {
                    Console.WriteLine(stat);
                }

                Console.WriteLine();

                void ContClass()
                {
                    string contOption;
                    Console.Write(ClassLibrary.DisplayMessages.ChooseNew());
                    contOption = Console.ReadLine();
                    contOption.ToUpper();

                    if (contOption == "Y")
                    {
                        InfoMenu();
                    }

                    else if (contOption == "N")
                    {
                        Exit();
                    }

                    // Create else statement incase user gives invalid input
                    else
                    {
                        Console.WriteLine(ClassLibrary.DisplayMessages.ExceptionHandle());
                        Console.WriteLine();
                        ContClass();
                    }


                }
                ContClass();


            }
            // Create a method to thank user for using the menu and exit
            void Exit()
            {

                Console.WriteLine("Thank you for using the Dungeon Crawler Info Menu!");
                Console.ReadLine();
            }

            void ComDamageTaken()
            {
                int damageTaken = ClassLibrary.RNG.DamageRecieved();

                if (damageTaken > 10)
                {
                    Console.WriteLine(ClassLibrary.DisplayMessages.CritHitTaken(damageTaken));
                }
                else if (damageTaken < 11)
                {
                    Console.WriteLine(ClassLibrary.DisplayMessages.NormHitTaken(damageTaken));
                }
                else
                {
                    Console.WriteLine(ClassLibrary.DisplayMessages.RunError());
                    StartMenu();
                }
                
            }
            void ComDamageDealt()
            {
                int damageDealt = ClassLibrary.RNG.DamageDealt();

                if (damageDealt > 10)
                {
                    Console.WriteLine(ClassLibrary.DisplayMessages.CritHitDealt(damageDealt));
                }
                else if (damageDealt < 11)
                {
                    Console.WriteLine(ClassLibrary.DisplayMessages.NormHitDealt(damageDealt));
                }
                else
                {
                    Console.WriteLine(ClassLibrary.DisplayMessages.RunError());
                    StartMenu();
                }
            }
            void DungeonStart()
            {
                int random = ClassLibrary.RNG.SpawnRNG();
                int check = 0;
                switch (random)
                {
                    case 1:
                        Console.WriteLine(ClassLibrary.DisplayMessages.SpawnFromNorth());
                        Console.WriteLine(ClassLibrary.DisplayMessages.DirecFromNorthSpawn());


                        
                        String strChoice1 =  Console.ReadLine();
                        while (!int.TryParse(strChoice1, out check))
                        {
                            Console.WriteLine(ClassLibrary.DisplayMessages.MenuError());
                            Console.WriteLine();
                            Console.WriteLine();
                            DungeonStart();
                        }
                        int choice1 = Convert.ToInt32(strChoice1);
                        switch (choice1)
                        {
                            case 1:
                                Console.WriteLine("TODO");
                                Console.ReadLine();
                                break;
                            case 2:
                                Console.WriteLine("TODO");
                                Console.ReadLine();
                                break;
                            case 3:
                                Console.WriteLine("TODO");
                                Console.ReadLine();
                                break;
                            case 4:
                                ComDamageDealt();
                                Console.WriteLine();
                                ComDamageTaken();
                                Console.ReadLine();
                                break;
                            case 5:
                                Exit();
                                break;


                        }



                        break;
                    case 2:
                        Console.WriteLine(ClassLibrary.DisplayMessages.SpawnFromSouth());
                        Console.WriteLine(ClassLibrary.DisplayMessages.DirecFromSouthSpawn());

                        String strChoice2 = Console.ReadLine();
                        while (!int.TryParse(strChoice2, out check))
                        {
                            Console.WriteLine(ClassLibrary.DisplayMessages.MenuError());
                            Console.WriteLine();
                            Console.WriteLine();
                            DungeonStart();
                        }
                        int choice2 = Convert.ToInt32(strChoice2);
                        switch (choice2)
                        {
                            case 1:
                                Console.WriteLine("TODO");
                                Console.ReadLine();
                                break;
                            case 2:
                                Console.WriteLine("TODO");
                                Console.ReadLine();
                                break;
                            case 3:
                                Console.WriteLine("TODO");
                                Console.ReadLine();
                                break;
                            case 4:
                                ComDamageDealt();
                                Console.WriteLine();
                                ComDamageTaken();
                                Console.ReadLine();
                                break;
                            case 5:
                                Exit();
                                break;


                        }
                        break;
                    case 3:
                        Console.WriteLine(ClassLibrary.DisplayMessages.SpawnFromEast());
                        Console.WriteLine(ClassLibrary.DisplayMessages.DirecFromEastSpawn());

                        String strChoice3 = Console.ReadLine();
                        while (!int.TryParse(strChoice3, out check))
                        {
                            Console.WriteLine(ClassLibrary.DisplayMessages.MenuError());
                            Console.WriteLine();
                            Console.WriteLine();
                            DungeonStart();
                        }
                        int choice3 = Convert.ToInt32(strChoice3);
                        switch (choice3)
                        {
                            case 1:
                                Console.WriteLine("TODO");
                                Console.ReadLine();
                                break;
                            case 2:
                                Console.WriteLine("TODO");
                                Console.ReadLine();
                                break;
                            case 3:
                                Console.WriteLine("TODO");
                                Console.ReadLine();
                                break;
                            case 4:
                                ComDamageDealt();
                                Console.WriteLine();
                                ComDamageTaken();
                                Console.ReadLine();
                                break;
                            case 5:
                                Exit();
                                break;


                        }
                        break;

                    case 4:
                        Console.WriteLine(ClassLibrary.DisplayMessages.SpawnFromWest());
                        Console.WriteLine(ClassLibrary.DisplayMessages.DirecFromWestSpawn());

                        String strChoice4 = Console.ReadLine();
                        while (!int.TryParse(strChoice4, out check))
                        {
                            Console.WriteLine(ClassLibrary.DisplayMessages.MenuError());
                            Console.WriteLine();
                            Console.WriteLine();
                            DungeonStart();
                        }
                        int choice4 = Convert.ToInt32(strChoice4);
                        switch (choice4)
                        {
                            case 1:
                                Console.WriteLine("TODO");
                                break;
                            case 2:
                                Console.WriteLine("TODO");
                                break;
                            case 3:
                                Console.WriteLine("TODO");
                                break;
                            case 4:
                                ComDamageDealt();
                                Console.WriteLine();
                                ComDamageTaken();
                                Console.ReadLine();
                                break;
                            case 5:
                                Exit();
                                break;


                        }
                        break;
                    default:
                        Console.WriteLine(ClassLibrary.DisplayMessages.RunError());
                        Console.WriteLine();
                        StartMenu();
                        break;
                        
                }
            }
            

            StartMenu();
            
        }
    }
}
