﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class RNG
    {
        public static int SpawnRNG()
        {
            Random random = new Random();
            return random.Next(1, 4);
        }
        public static int MobSpawnChance()
        {
            Random random = new Random();
            return random.Next(1, 5);
        }
        public static List<String> MobSpawnType()
        {
            
            Random random = new Random();
            int groups = random.Next(1, 3);
            List<String> mobTypes = new List<String>();
            List<int> mobSize = new List<int>(groups);
            foreach (int item in mobSize)
            {
                int type = random.Next(1, 5);
                switch (type)
                {
                    case 1:
                        mobTypes.Add("Goblin Lackey");
                        break;
                    case 2:
                        mobTypes.Add("Goblin Mage");
                        break;
                    case 3:
                        mobTypes.Add("Goblin Captain");
                        break;
                    case 4:
                        mobTypes.Add("Hobgoblin");
                        break;
                    case 5:
                        mobTypes.Add("Goblin Commander");
                        break;
                }
                    


                
            }

            return mobTypes;
        }

        public static int TreasureSpawnChance()
        {
            Random random = new Random();
            return random.Next(1, 25);
        }

        public static int DamageDealt()
        {

            Random random = new Random();

            return random.Next(1, 20);
        }
        public static int DamageRecieved()
        {

            Random random = new Random();

            return random.Next(1, 20);
        }

    }
}
