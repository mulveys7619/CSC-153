﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class DisplayMessages
    {
        public static String DisStartMenu()
        {
            return "Please select an option from the menu below\n" +
                  "===========================================\n" +
                  "1. Enter Dungeon\n" +
                  "2. Game Information\n" +
                  "3. Exit\n" +
                  "";
        }
        public static String ExceptionHandle()
        {
            return "ERROR: Please a valid option ('Y' or 'N').";
        }
        public static String ChooseNew()
        {
            return "Would you like to view another item from the menu?(Y/N): ";
        }
        public static String DisInfoMenu()
        {
            return "This menu provides information on various aspects of the Dungeon Crawler game\n" +
            "------------------------------------------------------------------------------\n" +
            "Select an option from the menu below to learn more about it.\n" +
            "==============================================================================\n" +
            "1. Beginner Classes\n" +
            "2. Dungeon Rooms\n" +
            "3. Potions\n" +
            "4. Treasure\n" +
            "5. Items\n" +
            "6. Weapons\n" +
            "7. Abilities\n" +
            "8. Mobs\n" +
            "9. Stats\n" +
            "10. Exit\n" +
            "Please select an option (1-10): ";
        }
        public static String MenuError()
        {
            return "ERROR: Please select a valid option from the Menu.";
        }

        public static String DisClassInfo()
        {

            return "CLASSES\n" +
            "------------";
        }
        public static String RunError()
        {
            return "An unknown error has occured.";
        }

        public static String CritHitTaken(int damage)
        {
            return "You were critically hit for " + damage + " points!";
        }
        public static String NormHitTaken(int damage)
        {
            return "You were dealt " + damage + " points of damage";
        }
        public static String CritHitDealt(int damage)
        {
            return "You critically hit for " + damage + " points!";
        }
        public static String NormHitDealt(int damage)
        {
            return "You  dealt " + damage + " points of damage";
        }
        public static String SpawnFromNorth()
        {
            return "You Enter the dungeon from the North";
        }
        public static String SpawnFromSouth()
        {
            return "You Enter the dungeon from the South";
        }
        public static String SpawnFromEast()
        {
            return "You Enter the dungeon from the East";
        }
        public static String SpawnFromWest()
        {
            return "You Enter the dungeon from the West";
        }
        public static String DirecFromNorthSpawn()
        {
            return "Choose a direction to go\n" +
                   "1. South\n" +
                   "2. East\n" +
                   "3. West\n" +
                   "4. Attack\n" +
                   "5. Exit Dungeon";
        }
        public static String DirecFromSouthSpawn()
        {
            return "Choose a direction to go\n" +
                   "1. North\n" +
                   "2. East\n" +
                   "3. West\n" +
                   "4. Attack\n" +
                   "5. Exit Dungeon";
        }
        public static String DirecFromEastSpawn()
        {
            return "Choose a direction to go\n" +
                   "1. South\n" +
                   "2. North\n" +
                   "3. West\n" +
                   "4. Attack\n" +
                   "5. Exit Dungeon";
        }
        public static String DirecFromWestSpawn()
        {
            return "Choose a direction to go\n" +
                   "1. South\n" +
                   "2. East\n" +
                   "3. North\n" +
                   "4. Attack\n" +
                   "5. Exit Dungeon";
        }


    }
}
