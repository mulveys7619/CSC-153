﻿/**
 * 02/20/2020
 * Sean Mulvey
 * Calculates retail price of an object by using wholesale price and markup percentage
 */



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        public static void Main(string[] args)
        {
            RetailCalculator();
        }
        public static void RetailCalculator()
        {
            Console.Write("What is the wholesale price?: ");
            double whole = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.Write("What is the markup percentage?: ");
            double perc = (Convert.ToDouble(Console.ReadLine()) / 100);

            Console.WriteLine();

            Console.WriteLine("Wholesale: " + whole.ToString("C"));
            Console.WriteLine("Markup: " + (perc * 100));
            Console.WriteLine("Retail: " + ClassLibrary.Calculations.CalculateRetail(whole, perc));
            Console.ReadLine();

        }
    }
}
