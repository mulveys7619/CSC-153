﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// 1/15/2019
// CSC 153
// Sean Mulvey
// Displays an Array of numbers

namespace DEMO
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create Array with given values as double data type
            double[] numbers = { 1245.67, 1189.55, 1098.72, 1456.88, 2109.34, 1987.55, 1872.36 };

            // Iterate through Array to print each item
            foreach (var item in numbers)
            {
                Console.WriteLine(item.ToString());
            }

            // Keep console open
            Console.ReadLine();



        }
    }
}