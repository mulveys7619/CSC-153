﻿/**
 * 02/09/2020
 * CSC 153
 * Sean Mulvey
 * Allows user to input ages and then display ages inputed and their average
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2HW2_MulveySean
{
    class Program
    {
        static void Main(string[] args)
        {
            // Display Menu for user to choose an option
            Console.WriteLine("Please select an option");
            Console.WriteLine("-----------------------");
            Console.WriteLine("1. Run Age List Program");
            Console.WriteLine("2. Exit");
            // Input menuChoice
            string menuChoice = Console.ReadLine();

            // If user chooses to run program, execute while loop
            while (menuChoice == "1")
            {
                // Ask user for number of ages
                Console.Write("How many ages would you like to input?: ");
                // Input strAgeAmount
                string strAgeAmount = Console.ReadLine();

                // Set int variable to check if user input was an int
                int check;

                // Compare strAgeAmount to check to see if strAgeAmount is an int
                while (!int.TryParse(strAgeAmount, out check))
                {
                    // If strAgeAmount is != check data type (int), ask user to enter strAgeAmount again
                    Console.Write("Please enter an integer for number of ages you would like to input: ");
                    // Input strAgeAmount
                    strAgeAmount = Console.ReadLine();
                }

                // Convert strAgeAmount to int with int ageAmount
                int ageAmount = Convert.ToInt32(strAgeAmount);

                // Create a running total in order to average the ages
                double runTotal = 0;

                // Create an empty list to add age inputs to
                List<int> ageList = new List<int>();

                // Create for loop to iterate for the amount of ages meant to be inputed
                for (int i = 0; i < ageAmount; i++)
                {
                    // Ask user to input age
                    Console.Write("Enter age " + (i + 1) + ":");
                    // Input strAge
                    string strAge = Console.ReadLine();

                    // Compare strAge to check to see if strAge is an int
                    while (!int.TryParse(strAge, out check))
                    {
                        // If strAge is != check data type (int), ask user to enter strAge again
                        Console.Write("Please enter an integer for age " + (i + 1) + ": ");
                        // Input strAge
                        strAge = Console.ReadLine();
                    }

                    // Convert strAge to int with int age
                    int age = Convert.ToInt32(strAge);

                    // Add age to the running total
                    runTotal = age + runTotal;
                    // Add age to the empty list
                    ageList.Add(age);

                }
                
                // Calcualte the average age
                double ageAverage = runTotal / ageAmount;

                Console.WriteLine();
                // Display ages the user inputed
                Console.WriteLine("Ages");
                Console.WriteLine("----");
                // Display contents of list that age was added to
                foreach (var item in ageList)
                {
                    Console.WriteLine(item);
                }
                Console.WriteLine();
                // Display average age
                Console.WriteLine("Age Average");
                Console.WriteLine("-----------");
                Console.WriteLine(ageAverage);

                // Exit while loop
                break;
                



            }
            Console.WriteLine();
            // Thank user for using the program
            Console.WriteLine("Thank you for using the program!");
            // Keep window from closing
            Console.ReadLine();
        }
    }
}
